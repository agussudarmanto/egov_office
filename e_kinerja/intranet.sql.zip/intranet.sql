-- phpMyAdmin SQL Dump
-- version 4.6.0
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Aug 24, 2016 at 06:11 AM
-- Server version: 5.6.29
-- PHP Version: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `intranet`
--
CREATE DATABASE IF NOT EXISTS `intranet` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `intranet`;

-- --------------------------------------------------------

--
-- Table structure for table `dukungan`
--

CREATE TABLE `dukungan` (
  `id` int(10) UNSIGNED NOT NULL,
  `dukungan` text NOT NULL,
  `created_time` datetime DEFAULT NULL,
  `modified_time` datetime DEFAULT NULL,
  `deleted` tinyint(4) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dukungan`
--

INSERT INTO `dukungan` (`id`, `dukungan`, `created_time`, `modified_time`, `deleted`) VALUES
(1, '-', NULL, NULL, 0),
(2, 'PPP - Public Private Partnership', NULL, NULL, 0),
(3, 'ARG - Anggaran Responsif Gender', NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE `groups` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `description`) VALUES
(1, 'admin', 'Administrator'),
(2, 'members', 'General User');

-- --------------------------------------------------------

--
-- Table structure for table `ikktahunan`
--

CREATE TABLE `ikktahunan` (
  `id` int(10) UNSIGNED NOT NULL,
  `indikatorkinerjakegiatan_id` int(10) UNSIGNED NOT NULL,
  `tahun` year(4) NOT NULL,
  `nilai` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ikstriwulan`
--

CREATE TABLE `ikstriwulan` (
  `id` int(10) UNSIGNED NOT NULL,
  `indikatorkinerjasasaran_id` int(10) UNSIGNED NOT NULL,
  `tahun` year(4) NOT NULL,
  `triwulan_id` int(11) NOT NULL,
  `target` int(10) UNSIGNED NOT NULL,
  `realisasi` int(10) UNSIGNED NOT NULL,
  `analisiscapaian` text,
  `faktorkeberhasilan` text,
  `faktorkegagalan` text,
  `solusi` text,
  `sumberdaya` text,
  `kegiatanpenunjang` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ikstriwulan`
--

INSERT INTO `ikstriwulan` (`id`, `indikatorkinerjasasaran_id`, `tahun`, `triwulan_id`, `target`, `realisasi`, `analisiscapaian`, `faktorkeberhasilan`, `faktorkegagalan`, `solusi`, `sumberdaya`, `kegiatanpenunjang`) VALUES
(1, 8, 2015, 1, 100, 100, '<p>Pada triwulan I target persentase arsip surat yang dapat ditemukan dengan mudah dan tepat waktu 100% dan direalisasikan 100%</p><ul><li>satu</li><li>dua</li><li>tiga</li></ul>', 'sas rwerwrwe', 'iuyiuyuiyui', 'uiyiuyui iu yui', '<ol><li>iuyuio</li><li>yiasda</li><li>sasdas</li><li>dasdasd</li></ol>', '<ol><li>iouuiyia</li><li>sdasd</li><li>asdasd</li></ol>'),
(2, 12, 2015, 1, 50, 40, 'Pada triwulan I target persentase arsip surat yang dapat ditemukan dengan mudah dan tepat waktu 100% dan direalisasikan 100%', '', '', '', '', ''),
(3, 8, 2015, 1, 100, 100, '<p>Pada triwulan I target persentase arsip surat yang dapat ditemukan dengan mudah dan tepat waktu 100% dan direalisasikan 100%</p><ul><li>satu</li><li>dua</li><li>tiga</li></ul>', 'sas rwerwrwe', 'iuyiuyuiyui', 'uiyiuyui iu yui', '<ol><li>iuyuio</li><li>yiasda</li><li>sasdas</li><li>dasdasd</li></ol>', '<ol><li>iouuiyia</li><li>sdasd</li><li>asdasd</li></ol>');

-- --------------------------------------------------------

--
-- Table structure for table `iku`
--

CREATE TABLE `iku` (
  `id` int(10) UNSIGNED NOT NULL,
  `unoreselon1_id` int(11) NOT NULL,
  `iku` text NOT NULL,
  `created_time` datetime DEFAULT NULL,
  `modified_time` datetime DEFAULT NULL,
  `deleted` tinyint(4) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `iku`
--

INSERT INTO `iku` (`id`, `unoreselon1_id`, `iku`, `created_time`, `modified_time`, `deleted`) VALUES
(1, 1, 'Tersedianya Dukungan Manajemen dan Tugas Teknis dalam Pelaksanaan Tugas Teknis Peradilan', NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `indikatorkinerjakegiatan`
--

CREATE TABLE `indikatorkinerjakegiatan` (
  `id` int(10) UNSIGNED NOT NULL,
  `sasaran_id` int(10) UNSIGNED NOT NULL,
  `dukungan_id` int(10) UNSIGNED NOT NULL,
  `kode` varchar(45) DEFAULT NULL,
  `indikatorkinerjakegiatan` text NOT NULL,
  `satuan` varchar(100) NOT NULL,
  `prioritas_id` tinyint(4) DEFAULT '2',
  `unggulan_id` tinyint(4) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `indikatorkinerjakegiatan`
--

INSERT INTO `indikatorkinerjakegiatan` (`id`, `sasaran_id`, `dukungan_id`, `kode`, `indikatorkinerjakegiatan`, `satuan`, `prioritas_id`, `unggulan_id`) VALUES
(1, 1, 1, '001', 'Terselenggaranya standarisasi layanan publik bagi instansi/lembaga publik', 'sistem', 2, 2),
(2, 1, 1, '002', 'Terselenggaranya kerjasama antar instansi pemerintah/swasta/lembaga terkait', 'kegiatan', 2, 2),
(3, 2, 1, '003', 'Jumlah data layanan informasi hukum dan peradilan', 'data', 2, 2),
(4, 3, 1, '001', 'Jumlah rekruitmen yang transparan, adil, akuntabel dan berdasarkan kompetensi (Calon Hakim, CPNS, Calon Hakim AdHoc Tipikor)', 'orang', 3, 2),
(5, 3, 1, '002', 'Jumlah pegawai yang mengikuti pembinaan bidang kepegawaian', 'orag', 3, 2),
(6, 4, 1, '003', 'Jumlah penyusunan laporan kegiatan pengelolaan administrasi kepegawaian', 'laporan', 3, 2),
(7, 5, 1, '001', 'Tersajinya kualitas laporan keuangan yang sesuai dengan sistem akuntansi aparatur yang mengikuti pembinaan teknis perbendaharaan', 'satker', 2, 2),
(8, 5, 1, '002', 'Terselenggaranya penyusunan laporan pengelolaan pelaksanaan anggaran', 'laporan', 2, 2),
(9, 5, 1, '003', 'Jumlah laporan pengelolaan Sistem Akuntansi Pemerintah (SAP)', 'laporan', 2, 2),
(10, 5, 1, '004', 'Jumlah laporan penatausahaan pembukuan verifikasi dan pelaksanaan anggaran', 'laporan', 2, 2),
(11, 5, 1, '005', 'Jumlah laporan penerimaan negara bukan pajak', 'laporan', 2, 2),
(12, 5, 1, '006', 'Terselenggaranya pembayaran gaji, tunjangan, operasional Badan Urusan Administrasi dan Pengadilan di lingkungan Mahkamah Agung', 'bulan layanan', 2, 2),
(13, 6, 1, '001', 'Terselenggaranya dokumen penyusunan rencana program', 'dokumen', 2, 2),
(14, 6, 1, '002', 'Terselenggaranya dokumen penyusunan rencana anggaran', 'dokumen', 2, 2),
(15, 6, 1, '005', 'Terselenggaranya rekomendasi pembaruan Peradilan', 'rekomendasi', 2, 2),
(16, 6, 1, '006', 'Terselenggaranya dokumen rekomendasi evaluasi output', 'dokumen', 2, 2),
(17, 6, 1, '007', 'Terselenggaranya dokumen hasil inventarisir dan telaahan laporan', 'dokumen', 2, 2),
(18, 6, 1, '008', 'Terselenggaranya monitoring kinerja penganggaran dan bimbingan teknis perencanaan dan anggaran', 'laporan', 2, 2),
(19, 6, 1, '009', 'Terselenggaranya penyusunan anggaran berbasis gender', 'dokumen', 2, 2),
(20, 7, 1, '003', 'Terselenggaranya rekomendasi kebijakan bidang kelembagaan Mahkamah Agung', 'rekomendasi', 2, 2),
(21, 7, 1, '004', 'Terselenggaranya laporan reformasi birokrasi di Lingkungan Mahkamah Agung', 'laporan', 2, 2),
(22, 8, 1, '001', 'Dokumentasi analisa administrasi sarana dan prasarana dilingkungan Mahkamah Agung dan badan peradilan di bawahnya', 'laporan', 2, 2),
(23, 8, 1, '002', 'Jumlah keputusan penghapusan, ahli fungsi dan tukar menukar BMN', 'SK', 2, 2),
(24, 9, 1, '001', 'Terselenggaranya pelayanan penyelesaian urusan administrasi kepada pimpinan Mahkamah Agung', 'bulan', 2, 2),
(25, 10, 1, '001', 'Jumlah pegawai yang mengikuti pembinaan administrasi umum', 'orang', 2, 2),
(26, 10, 1, '002', 'Terselenggaranya urusan tata usaha, rumah tangga, bina sikap mental di lingkungan Mahkamah Agung', 'bulan', 2, 2),
(27, 11, 1, '001', 'Jumlah pengadaan tanah di lingkungan Mahkamah Agung', 'satker', 2, 2),
(28, 11, 1, '002', 'Jumlah pengadaan sertifikat tanah di lingkungan Mahkamah Agung', 'satker', 2, 2),
(29, 11, 1, '003', 'Jumlah pengadaan jaringan instalasi di lingkungan Mahkamah Agung', 'satker', 2, 2),
(30, 11, 1, '004', 'Jumlah pengadaan IT/CTS di lingkungan Mahkamah Agung', 'satker', 2, 2),
(31, 11, 1, '005', 'Jumlah pengadaan buku ukum di lingkungan Mahkamah Agung', 'satker', 2, 2),
(32, 11, 1, '006', 'Jumlah pengadaan kendaraan operasional roda empat untuk pengadilan di lingkungan Mahkamah Agung', 'satker', 2, 2),
(33, 11, 1, '007', 'Jumlah pengadaan perangkat pengolah data dan komunikasi', 'satker', 2, 2),
(34, 11, 1, '008', 'Jumlah pengadaan peralatan/fasilitas (meubelair) kantor di lingkungan Mahkamah Agung', 'satker', 2, 2),
(35, 11, 1, '009', 'Jumlah pengadaan gedung kantor di lingkungan Mahkamah Agung', 'satker', 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `indikatorkinerjasasaran`
--

CREATE TABLE `indikatorkinerjasasaran` (
  `id` int(10) UNSIGNED NOT NULL,
  `indikatorkinerjakegiatan_id` int(10) UNSIGNED NOT NULL,
  `unoreselon3_id` int(11) NOT NULL,
  `kode` varchar(45) DEFAULT NULL,
  `indikatorkinerjasasaran` text NOT NULL,
  `satuan` varchar(100) NOT NULL,
  `deskripsi` text NOT NULL,
  `prioritas_id` tinyint(4) DEFAULT '2'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `indikatorkinerjasasaran`
--

INSERT INTO `indikatorkinerjasasaran` (`id`, `indikatorkinerjakegiatan_id`, `unoreselon3_id`, `kode`, `indikatorkinerjasasaran`, `satuan`, `deskripsi`, `prioritas_id`) VALUES
(8, 4, 4, '01', 'Rekrutmen Calon Hakim dan calon Pegawai Negeri Sipil', 'orang', 'adalah persentase surat yang masuk pada pimpinan Mahkamah Agung RI yang ditindaklanjuti oleh bagian pelayanan administrasi persuratan Biro Kesekretariatan Pimpinan sesuai dengan SOP yang berlaku untuk meningkatkan kualitas pelayanan administrasi persuratan.', 2),
(9, 4, 4, '02', 'Rekrutmen Hakim Ad Hoc Tindak pidana Korupsi (Tipikor)', 'orang', 'Laporan mengenai', 2),
(11, 4, 4, '03', 'Rekrutmen pegawai dalam Jabatan Fungsional', 'orang', '', 2),
(12, 5, 4, '002', 'Ini tes indikator kinerja sasaran', 'dokumen', 'Merupakan IKS tentang', 0),
(13, 24, 4, '01', 'Persentase dokumen surat yang ditindaklanjuti sesuai SOP', 'persentase', 'persentase surat yang masuk pada pimpinan Mahkamah Agung RI yang ditindaklanjuti oleh bagian pelayanan administrasi persuratan Biro Kesekretariatan Pimpinan sesuai dengan SOP yang berlaku untuk meningkatkan kualitas pelayanan administrasi persuratan.\r\nIndikator kinerja ini mengukur keberhasilan peningkatan kualitas pelayanan administrasi persuratan pada unit tata persuratan Biro Kesekretariatan Pimpinan.', 0);

-- --------------------------------------------------------

--
-- Table structure for table `jenisoutput`
--

CREATE TABLE `jenisoutput` (
  `id` int(10) UNSIGNED NOT NULL,
  `jenisoutput` text NOT NULL,
  `created_time` datetime DEFAULT NULL,
  `modified_time` datetime DEFAULT NULL,
  `deleted` tinyint(4) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jenisoutput`
--

INSERT INTO `jenisoutput` (`id`, `jenisoutput`, `created_time`, `modified_time`, `deleted`) VALUES
(1, 'OU - Output Utama', NULL, NULL, 0),
(2, 'OP - Output Pendukung', NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `kegiatan`
--

CREATE TABLE `kegiatan` (
  `id` int(10) UNSIGNED NOT NULL,
  `unoreselon1_id` int(11) NOT NULL,
  `unoreselon2_id` int(11) NOT NULL,
  `kode` varchar(45) DEFAULT NULL,
  `kegiatan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `kegiatan`
--

INSERT INTO `kegiatan` (`id`, `unoreselon1_id`, `unoreselon2_id`, `kode`, `kegiatan`) VALUES
(1, 1, 1, '1064', 'Peningkatan Pelayanan Informasi pada Mahkamah Agung dan Pengadilan Semua Lingkungan Peradilan AGS'),
(2, 1, 2, '1065', 'Pembinaan Administrasi Pengelolaan Kepegawaian dan Pengembangan SDM'),
(3, 1, 3, '1066', 'Pembinaan Administrasi dan Pengelolaan Keuangan Badan Urusan Administrasi'),
(4, 1, 1, '1067', 'Pelaksanaan Penyusunan Perencanaan dan Anggaran serta Penataaan Organisasi Mahkamah Agung'),
(5, 1, 4, '1068', 'Pembinaan Admnistrasi Pengelolaan Perlengkapan Sarana dan Prasarana di Lingkungan Mahkamahh Agung dan Badan Peradilan yang berada di bawahnya'),
(6, 1, 5, '1069', 'Dukungan Pelayanan Pimpinan Mahkamah Agung dan Tugas Teknis Lainnya'),
(7, 1, 7, '1070', 'Pelaksanaan Pembinaan Keamanan, Urusan Tata Usaha, Rumah Tangga, Bina Sikap Mental di Lingkungan Mahkamah Agung'),
(8, 1, 4, '1071', 'Pengadaan Sarana dan Prasarana di Lingkungan Mahkamah Agung');

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

CREATE TABLE `login_attempts` (
  `id` int(11) UNSIGNED NOT NULL,
  `ip_address` varchar(15) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `misi`
--

CREATE TABLE `misi` (
  `id` tinyint(4) NOT NULL,
  `unoreselon1_id` int(11) NOT NULL,
  `misi` text NOT NULL COMMENT 'Misi unit organisasi'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `misi`
--

INSERT INTO `misi` (`id`, `unoreselon1_id`, `misi`) VALUES
(1, 1, 'Meningkatkan kemampuan dan kuantitas sumber daya manusia'),
(2, 1, 'Meningkatkan akuntabilitas kinerja pegawai'),
(3, 1, 'Meningkatkan kualitas pelayanan publik'),
(4, 1, 'Meningkatkan kualitas perencanaan dan penganggaran'),
(5, 1, 'Meningkatkan kelembagaan/organisasi peradilan yang efektif dan efisien'),
(6, 1, 'Meningkatkan pengelolaan anggaran secara akuntabel dan transparan'),
(7, 1, 'Meningkatkan sistem informasi yang handal dan profesional'),
(8, 1, 'Meningkatkan ketatalaksanaan yang berkualitas'),
(9, 1, 'Meningkatkan penatausahaan aset negara'),
(10, 1, 'Meningkatkan pelayanan administrasi');

-- --------------------------------------------------------

--
-- Table structure for table `outcome`
--

CREATE TABLE `outcome` (
  `id` int(10) UNSIGNED NOT NULL,
  `unoreselon1_id` int(11) NOT NULL,
  `outcome` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `outcome`
--

INSERT INTO `outcome` (`id`, `unoreselon1_id`, `outcome`) VALUES
(1, 1, 'Dukungan Manajemen dan Tugas Teknis Dalam Penyelenggaraan Fungsi Peradilan');

-- --------------------------------------------------------

--
-- Table structure for table `output`
--

CREATE TABLE `output` (
  `id` int(10) UNSIGNED NOT NULL,
  `indikatorkinerjakegiatan_id` int(10) UNSIGNED NOT NULL,
  `unoreselon3_id` int(11) NOT NULL,
  `kode` varchar(45) DEFAULT NULL,
  `output` text NOT NULL,
  `jenisoutput_id` varchar(100) NOT NULL,
  `deskripsi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `output`
--

INSERT INTO `output` (`id`, `indikatorkinerjakegiatan_id`, `unoreselon3_id`, `kode`, `output`, `jenisoutput_id`, `deskripsi`) VALUES
(1, 1, 0, '001', 'Sistem Informasi Peradilan', '2', ''),
(2, 2, 0, '002', 'Hubungan Antar Unit/Satker/Lembaga/Masyarakat', '2', ''),
(3, 3, 0, '003', 'Layanan Informasi Hukum dan Peradilan', '2', ''),
(4, 4, 0, '001', 'Pegawai yang direkrut', '1', ''),
(5, 5, 0, '002', 'Pegawai yang mengikuti pembinaan bidang kepegawaian', '2', ''),
(6, 6, 0, '003', 'Laporan kepegawaian', '2', ''),
(7, 7, 0, '002', 'Aparatur yang mengikuti pembinaan teknis perbendaharaan', '2', ''),
(8, 8, 0, '003', 'Laporan pengelolaan pelaksanaan anggaran', '2', ''),
(9, 9, 0, '004', 'Laporan pengelolaan Sistem Akuntansi Pemerintah (SAP)', '2', ''),
(10, 10, 0, '005', 'Laporan penatausahaan pembukuan verifikasi dan pelaksanaan anggaran', '2', ''),
(11, 11, 0, '006', 'Laporan penerimaan negara bukan pajak', '2', ''),
(12, 12, 0, '994', 'Layanan perkantoran', '1', ''),
(13, 13, 0, '001', 'Dokumen rencana program Mahkamah Agung RI', '2', ''),
(14, 14, 0, '002', 'Dokumen rencana anggaran Mahkamah Agung RI', '2', ''),
(15, 15, 0, '005', 'Rekomendasi pembaruan Peradilan', '2', ''),
(16, 16, 0, '006', 'Dokumen rekomendasi evaluasi output', '2', ''),
(17, 17, 0, '007', 'Dokumen hasil inventarisir dan telaahan laporan', '2', ''),
(18, 18, 0, '008', 'Laporan Monitoring kinerja penganggaran dan bimbingan teknis perencanaan dan anggaran', '2', ''),
(19, 19, 0, '009', 'Penyusunan anggaran berbasis gender', '2', ''),
(20, 20, 0, '003', 'Kebijakan bidang kelembagaan Mahkamah Agung', '2', ''),
(21, 21, 0, '004', 'Laporan reformasi birokrasi di Lingkungan Mahkamah Agung', '2', ''),
(22, 22, 0, '001', 'Laporan Barang Inventaris Milik Negara', '2', ''),
(23, 23, 0, '002', 'Keputusan penghapusan, alih fungsi dan tukar menukar BMN', '2', ''),
(24, 24, 0, '001', 'Layanan pimpinan', '1', ''),
(25, 24, 0, '002', 'Layanan kegiatan', '2', ''),
(26, 24, 0, '994', 'Layanan perkantoran', '2', ''),
(27, 25, 0, '002', 'Aparatur yang mengikuti pembinaan administrasi umum', '2', ''),
(28, 26, 0, '994', 'Layanan perkantoran', '2', '');

-- --------------------------------------------------------

--
-- Table structure for table `pktbiro`
--

CREATE TABLE `pktbiro` (
  `id` int(10) UNSIGNED NOT NULL,
  `unoreselon2_id` tinyint(3) UNSIGNED DEFAULT NULL,
  `kode` varchar(10) DEFAULT NULL,
  `pktbiro` text,
  `jumlah` int(11) DEFAULT NULL,
  `satuan` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pktbiro`
--

INSERT INTO `pktbiro` (`id`, `unoreselon2_id`, `kode`, `pktbiro`, `jumlah`, `satuan`) VALUES
(1, 2, '201', 'Rekrutmen Calon Hakim dan calon Pegawai Negeri Sipil', 100, '%'),
(2, 2, '201', 'Rekrutmen Hakim Ad Hoc Tindak pidana Korupsi (Tipikor)', 100, '%'),
(3, 2, '201', 'Rekrutmen pegawai dalam Jabatan Fungsional', 100, '%'),
(4, 2, '202', 'Persentase penyelesaian administrasi muutasi pegawai sesuai peraturan yang berlaku', 100, '%'),
(5, 2, '202', 'Persentase penyelesaian administrasi promosi pegawai sesuai peraturan yang berlaku', 100, '%'),
(6, 2, '202', 'Persentase penyelesaian adminsitrasi kenaikan pangkat pegawai sesuai peraturan yang berlaku', 100, '%'),
(7, 2, '202', 'Persentase penyerapan anggaran kegiatan pembinaan pengelolaan kepegawaian', 100, '%'),
(8, 2, '203', 'Persentase aparatur yang mengikuti ujian dinas tingkat I, II dan Penyesuaian Ijazah', 100, '%'),
(9, 2, '203', 'Persentase pengelolaan data aparatur peradilan non teknis', 100, '%'),
(10, 2, '203', 'Persentase dokumen penghargaan yang diselesaikan tepat waktu', 100, '%'),
(11, 2, '204', 'Persentase penyelesaian administrasi pensiun tepat waktu', 100, '%'),
(12, 2, '204', 'Persentase penyelesaian administrasi hukuman disiplin', 100, '%'),
(13, 2, '205', 'Persentase penetapan angka kredit pegawai dalam jabatan fungsional', 100, '%'),
(14, 2, '205', 'Persentase pegawai yang telah diangkat dalam jabatan fungsional', 100, '%'),
(15, 2, '205', 'Persentase evaluasi pegawai dalam jabatan fungsional', 100, '%'),
(16, 3, '301', 'Jumlah satker yang mencapai realisasi anggaran DIPA diatas 90 % sesuai dengan peraturan yang berlaku ', 1652, 'satker'),
(17, 3, '302', 'Persentase temuan pemeriksaan BPK RI yang ditindaklanjuti sesuai rekomendasi', 90, '%'),
(18, 3, '303', 'Persentase satuan organisasi yang menerima tunjangan khusus kinerja tepat waktu', 100, '%'),
(19, 3, '304', 'Jumlah Satuan Kerja  yang menyusun laporan keuangan sesuai dengan peraturan yang berlaku ', 1652, 'satker'),
(20, 3, '305', 'Persentase Satuan Kerja yang melaksanakan penatausahaan dan pembukuan sesuai dengan peraturan yang berlaku dari 299 satuan organisasi', 95, '%'),
(21, 3, '306', 'Persentase temuan kerugian negara yang ditindaklanjuti ', 100, '%'),
(22, 3, '307', 'Persentase kasus kerugian negara yang telah lunas ', 60, '%'),
(23, 3, '308', 'Persentase target dan realisasi PNBP Mahkamah Agung dan Badan Peradilan yang berada dibawahnya sesuai dengan peraturan yang berlaku', 100, '%'),
(24, 3, '309', 'Jumlah satuan kerja yang mengirimkan laporan realisasi PNBP tepat waktu ', 1587, 'satker'),
(25, 4, '401', 'Jumlah Wilayah yang melaksanakan Penetapan Status', 10, 'wilayah'),
(26, 4, '401', 'Jumlah wilayah yang sudah dilaksanakan inventarisasi asset pada Pengadilan Perikanan yang berasal dari Kementerian Kelautan dan Perikanan (KKP)', 7, 'wilayah'),
(27, 4, '401', 'Jumlah satuan kerja yang sudah dilaksanakan tindaklanjut perbaikan nilai normalisasi hasil migrasi dan penyusutan BMN', 32, 'wilayah'),
(28, 4, '402', 'Jumlah Usulan Penghapusan BMN yang ditindaklanjuti tepat waktu', 180, 'satker'),
(29, 4, '402', 'Jumlah Usulan Ruislag/Tukar menukar BMN yang ditindaklanjuti tepat waktu', 5, 'satker'),
(30, 4, '402', 'Jumlah Usulan Hibah BMN yang ditindaklanjuti tepat waktu', 5, 'satker'),
(31, 4, '402', 'Jumlah Usulan Pinjam pakai tanah dan bangunan yang ditindaklanjuti tepat waktu', 5, 'satker'),
(32, 4, '402', 'Jumlah Usulan Alih Fungsi BMN yang ditindaklanjuti tepat waktu', 30, 'satker'),
(33, 4, '402', 'Jumlah Usulan Permohonan Persetujuan Sewa BMN', 10, 'satker'),
(34, 4, '403', 'Pengadaan Tanah Gedung Kantor', 3, 'satker'),
(35, 4, '403', 'Pengadaan Tanah Rumah Dinas', 5, 'satker'),
(36, 4, '403', 'Pembangunan Gedung Prototype', 40, 'satker'),
(37, 4, '403', 'Pembangunan Lanjutan Gedung Kantor', 89, 'satker'),
(38, 4, '403', 'Pembangunan Rumah Dinas', 5, 'unit'),
(39, 4, '403', 'Rehab Rumah Dinas', 3, 'unit'),
(40, 4, '403', 'Pembangunan Sarana dan Lingkungan Kantor', 32, 'satker'),
(41, 4, '403', 'Kendaraan Roda 2', 22, 'unit'),
(42, 4, '403', 'Kendaraan Roda 4', 73, 'unit'),
(43, 5, '501', 'Persentase dokumen surat yang ditindaklanjutisesuai SOP', 100, '%'),
(44, 5, '501', 'Persentase arsip surat yang dapat ditemukan dengan mudah dan tepat waktu', 100, '%'),
(45, 5, '501', 'Persentase SK Pimpinan yang ditindaklanjuti dengan tepat waktu dan akurat', 100, '%'),
(46, 5, '501', 'Persentase penyelesaian pengagendaan surat Pimpinan dengan menggunakan aplikasi persuratan', 40, '%'),
(47, 5, '501', 'Persentase anggaran operasional pimpinan yang dilaksanakan', 94, '%'),
(48, 5, '501', 'Persentase pemenuhan dokumen jadwal kegiatan pimpinan', 40, '%'),
(49, 5, '501', 'Jumlah kegiatan Biro Kesekretariatan Pimpinan yang dilaksanakan tepat waktu dan sesuai dengan tugas dan fungsi Biro', 4, 'kegiatan'),
(50, 6, '601', 'Jumlah aplikasi yang diimplementasikan di lingkungan MA dan pengadilan di bawahnya', 52, 'aplikasi'),
(51, 6, '601', 'Jumlah sistem aplikasi yang terintegrasi', 15, 'aplikasi'),
(52, 6, '601', 'Jumlah satker yang memiliki sistem informasi terintegrasi', 500, 'satker'),
(53, 6, '602', 'Tersedianya sarana dan prasarana teknologi informasi pada Mahkamah Agung', 40, 'KVA daya UPS'),
(54, 6, '602', 'Jumlah Satuan Organisasi  yang dapat mengakses server di data center Mahkamah Agung', 833, 'satuan organisasi'),
(55, 6, '603', 'Adanya Jaringan Antar Lembaga penerbit Peraturan Perudang-undangan', 44, 'peserta'),
(56, 6, '603', 'Pembinaan Legal Drafter', 12, 'peserta'),
(57, 6, '603', 'Pengelolaan dan Penggandaan Yurisprudensi', 1300, 'eksemplar'),
(58, 6, '603', 'Jumlah Kumpulan Peraturan Perundang-undangan dan Bahan Hukum Lainnya dalam Media yang Mutahir', 5800, 'eksemplar'),
(59, 6, '604', 'Jumlah Satuan Organisasi yang mengikuti sosialisasi pemberdayaan perpustakaan', 37, 'satuan organisasi'),
(60, 6, '604', 'Jumlah buku yang dipinjam di Perpustakaan MA', 992, 'buku'),
(61, 6, '604', 'Jumlah kunjungan pemustaka ke perpustakaan MA', 2954, 'orang'),
(62, 6, '605', 'Jumlah kegiatan pendampingan kunjungan kerja antar lembaga', 6, 'kegiatan'),
(63, 6, '605', 'Jumlah Satuan Organisasi yang memiliki Meja Informasi', 122, 'satker'),
(64, 7, '701', 'Persentase tertib dan aman dari pengaduan tindak kejahatan', 100, '%'),
(65, 7, '702', 'Persentase surat masuk yang didistribusikan sesuai SOP', 100, '%'),
(66, 7, '702', 'Jumlah Pegawai yang mengikuti pembinaan Tata Persuratan dan Kearsipan', 96, 'orang'),
(67, 7, '703', 'Jumlah luas Gedung dan Halaman yang terawat', 109236, 'm2'),
(68, 7, '703', 'Jumlah Sarana Gedung yang dimanfaatkan', 14, 'unit'),
(69, 7, '703', 'Jumlah Kendaraan dinas yang bisa di operasionalkan', 186, 'unit'),
(70, 7, '703', 'Persentase penemuan kembali arsip in aktif dengan mudah', 95, '%'),
(71, 7, '704', 'Persentase Pegawai Mahkamah Agung yang sehat jasmani dan rohani', 100, '%'),
(72, 7, '704', 'Jumlah Pegawai yang mengikuti ESQ', 150, 'orang'),
(73, 7, '705', 'Pengadaan/Perbaikan Instalasi', 3, 'instalasi'),
(74, 7, '705', 'Pengadaan/Perbaikan Teknologi Informasi', 1, 'sistem'),
(75, 7, '705', 'Pengadaan Perbaikan Kendaraan Bermotor', 7, 'unit'),
(76, 7, '705', 'Pengadaan Peralatan Pengolah Data & Komunikasi', 99, 'unit'),
(77, 7, '705', 'Pengadaan Peralatan dan Fasilitas Perkantoran', 311, 'unit'),
(78, 7, '705', 'Pembangunan/Renovasi Gedung & Bangunan', 38074, 'm2');

-- --------------------------------------------------------

--
-- Table structure for table `prioritas`
--

CREATE TABLE `prioritas` (
  `id` int(10) UNSIGNED NOT NULL,
  `prioritas` text NOT NULL,
  `created_time` datetime DEFAULT NULL,
  `modified_time` datetime DEFAULT NULL,
  `deleted` tinyint(4) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `prioritas`
--

INSERT INTO `prioritas` (`id`, `prioritas`, `created_time`, `modified_time`, `deleted`) VALUES
(0, 'Bukan prioritas', NULL, NULL, 0),
(1, 'N - Prioritas Nasional', NULL, NULL, 0),
(2, 'KL - Prioritas K/L', NULL, NULL, 0),
(3, 'B - Prioritas Bidang', NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `program`
--

CREATE TABLE `program` (
  `id` int(10) UNSIGNED NOT NULL,
  `unoreselon1_id` int(11) NOT NULL,
  `kode` varchar(45) DEFAULT NULL,
  `program` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `program`
--

INSERT INTO `program` (`id`, `unoreselon1_id`, `kode`, `program`) VALUES
(1, 1, '005.01.01', 'Program dukungan manajemen dan pelaksanaan tugas teknis lainnya Mahkmah Agung');

-- --------------------------------------------------------

--
-- Table structure for table `sasaran`
--

CREATE TABLE `sasaran` (
  `id` int(10) UNSIGNED NOT NULL,
  `kegiatan_id` int(10) UNSIGNED NOT NULL,
  `kode` varchar(45) DEFAULT NULL,
  `sasaran` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sasaran`
--

INSERT INTO `sasaran` (`id`, `kegiatan_id`, `kode`, `sasaran`) VALUES
(1, 1, '01', 'Meningkatnya pembinaan dan komunikasi kepada masyarakat mengenai kinerja pengadilan melalui teknologi informasi'),
(2, 1, '02', 'Meningkatnya pembinaan dan komunikasi kepada masyarakat mengenai kegiatan-kegiatan di bidang perpustakaan di lingkungan Mahkamah Agung dan Pengadilan di semua lingkungan'),
(3, 2, '01', 'Meningkatnya kepengurusan kepegawaian di lingkungan Mahkamah Agung dan Pengadilan di semua lingkungan peradilan'),
(4, 2, '02', 'Meningkatnya pengelolaan administrasi kepegawaian dalam jabatan fungsional di lingkungan Mahkamah Agung dan Pengadilan di semua lingkungan peradilan'),
(5, 3, '01', 'Meningkatnya pengelolaan keuangan yang akuntabel di lingkungan Mahkamah Agung dan Pengadilan di semua lingkungan'),
(6, 4, '01', 'Meningkatnya koordinasi dan terbinanya penyusunan rencana, program dan anggaran pada Mahkamah Agung dan 4 lingkungan peradilan di bawahnya'),
(7, 4, '02', 'Meningkatnya koordinasi dan terbinanya penataan organisasi dan tatalaksana dilingkungan Mahkamah Agung dan Pengadilan di semua lingkungan peradilan'),
(8, 5, '01', 'Meningkatnya pengelolaan IKN Mahkamah Agung dan 4 lingkungan peradilan'),
(9, 6, '01', 'Meningkatnya Kualitas Pelayanan Administrasi Kepada Pimpinan Mahkamah Agung RI'),
(10, 7, '01', 'Meningkatnya pembinaan urusan rumah tangga, sikap mental, tata usaha dan keamanan di lingkungan Mahkamah Agung'),
(11, 8, '01', 'Terpenuhinya sarana dan prasarana dalam penyelenggaraan di lingkungan Mahkamah Agung');

-- --------------------------------------------------------

--
-- Table structure for table `sasaranstrategis`
--

CREATE TABLE `sasaranstrategis` (
  `id` int(10) UNSIGNED NOT NULL,
  `unoreselon1_id` int(11) NOT NULL,
  `sasaranstrategis` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sasaranstrategis`
--

INSERT INTO `sasaranstrategis` (`id`, `unoreselon1_id`, `sasaranstrategis`) VALUES
(1, 1, 'Meningkatnya keterbukaan informasi'),
(2, 1, 'Peningkatan kualitas sumber daya manusia');

-- --------------------------------------------------------

--
-- Table structure for table `triwulan`
--

CREATE TABLE `triwulan` (
  `id` int(10) UNSIGNED NOT NULL,
  `triwulan` text NOT NULL,
  `created_time` datetime DEFAULT NULL,
  `modified_time` datetime DEFAULT NULL,
  `deleted` tinyint(4) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `triwulan`
--

INSERT INTO `triwulan` (`id`, `triwulan`, `created_time`, `modified_time`, `deleted`) VALUES
(1, 'I', NULL, NULL, 0),
(2, 'II', NULL, NULL, 0),
(3, 'III', NULL, NULL, 0),
(4, 'IV', NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `unggulan`
--

CREATE TABLE `unggulan` (
  `id` int(10) UNSIGNED NOT NULL,
  `unggulan` text NOT NULL,
  `created_time` datetime DEFAULT NULL,
  `modified_time` datetime DEFAULT NULL,
  `deleted` tinyint(4) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `unggulan`
--

INSERT INTO `unggulan` (`id`, `unggulan`, `created_time`, `modified_time`, `deleted`) VALUES
(0, 'Biasa', NULL, NULL, 0),
(1, 'Unggulan', NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `unoreselon1`
--

CREATE TABLE `unoreselon1` (
  `id` int(11) NOT NULL,
  `unoreselon1` text NOT NULL COMMENT 'Unit organisasi Eselon I',
  `created_time` datetime DEFAULT NULL,
  `modified_time` datetime DEFAULT NULL,
  `deleted` tinyint(4) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `unoreselon1`
--

INSERT INTO `unoreselon1` (`id`, `unoreselon1`, `created_time`, `modified_time`, `deleted`) VALUES
(1, 'Badan Urusan Administrasi', NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `unoreselon2`
--

CREATE TABLE `unoreselon2` (
  `id` int(11) NOT NULL,
  `unoreselon1_id` int(11) NOT NULL,
  `unoreselon2` varchar(250) NOT NULL COMMENT 'Unit organisasi Eselon I'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `unoreselon2`
--

INSERT INTO `unoreselon2` (`id`, `unoreselon1_id`, `unoreselon2`) VALUES
(1, 1, 'Biro Perencanaan dan Organisasi'),
(2, 1, 'Biro Kepegawaian'),
(3, 1, 'Biro Keuangan'),
(4, 1, 'Biro Perlengkapan'),
(5, 1, 'Biro Kesekretariatan Pimpinan'),
(6, 1, 'Biro Hukum dan Humas'),
(7, 1, 'Biro Umum');

-- --------------------------------------------------------

--
-- Table structure for table `unoreselon3`
--

CREATE TABLE `unoreselon3` (
  `id` int(11) NOT NULL,
  `unoreselon2_id` int(11) NOT NULL,
  `unoreselon3` varchar(250) NOT NULL COMMENT 'Unit organisasi Eselon I'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `unoreselon3`
--

INSERT INTO `unoreselon3` (`id`, `unoreselon2_id`, `unoreselon3`) VALUES
(4, 1, 'Bagian Organisasi dan Tata Laksana');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `ip_address` varchar(15) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) UNSIGNED DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` int(11) UNSIGNED NOT NULL,
  `last_login` int(11) UNSIGNED DEFAULT NULL,
  `active` tinyint(1) UNSIGNED DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES
(1, '127.0.0.1', 'administrator', '$2a$07$SeBknntpZror9uyftVopmu61qg0ms8Qv1yV6FG.kQOSM.9QhmTo36', '', 'admin@admin.com', '', NULL, NULL, 'mz2ZFGK.lp2xu9zn2SpknO', 1268889823, 1432698091, 1, 'Agus', 'Sudarmanto, S.Kom', 'ADMIN', '0');

-- --------------------------------------------------------

--
-- Table structure for table `users_groups`
--

CREATE TABLE `users_groups` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL,
  `group_id` mediumint(8) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users_groups`
--

INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES
(1, 1, 1),
(2, 1, 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dukungan`
--
ALTER TABLE `dukungan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ikktahunan`
--
ALTER TABLE `ikktahunan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_targettahunan_indikatorkinerjakegiatanunor1_idx` (`indikatorkinerjakegiatan_id`);

--
-- Indexes for table `ikstriwulan`
--
ALTER TABLE `ikstriwulan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_targettriwulan_indikatorkinerja1_idx` (`indikatorkinerjasasaran_id`);

--
-- Indexes for table `iku`
--
ALTER TABLE `iku`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_ikuunor_unoreselon11_idx` (`unoreselon1_id`);

--
-- Indexes for table `indikatorkinerjakegiatan`
--
ALTER TABLE `indikatorkinerjakegiatan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_indikatorkinerjakegiatanunor_sasarankegiatanunor1_idx` (`sasaran_id`),
  ADD KEY `fk_indikatorkinerjakegiatanunor_dukungan1_idx` (`dukungan_id`);

--
-- Indexes for table `indikatorkinerjasasaran`
--
ALTER TABLE `indikatorkinerjasasaran`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_indikatorkinerja_indikatorkinerjakegiatanunor1_idx` (`indikatorkinerjakegiatan_id`),
  ADD KEY `fk_indikatorkinerja_unoreselon31_idx` (`unoreselon3_id`);

--
-- Indexes for table `jenisoutput`
--
ALTER TABLE `jenisoutput`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kegiatan`
--
ALTER TABLE `kegiatan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_kegiatanunor_unoreselon11_idx` (`unoreselon1_id`),
  ADD KEY `fk_kegiatanunor_unoreselon21_idx` (`unoreselon2_id`);

--
-- Indexes for table `login_attempts`
--
ALTER TABLE `login_attempts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `misi`
--
ALTER TABLE `misi`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_misiunor_unoreselon1_idx` (`unoreselon1_id`);

--
-- Indexes for table `outcome`
--
ALTER TABLE `outcome`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_outcomeunor_unoreselon11_idx` (`unoreselon1_id`);

--
-- Indexes for table `output`
--
ALTER TABLE `output`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_output_indikatorkinerjakegiatan_idx` (`indikatorkinerjakegiatan_id`),
  ADD KEY `fk_output_unoreselon31_idx` (`unoreselon3_id`);

--
-- Indexes for table `pktbiro`
--
ALTER TABLE `pktbiro`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prioritas`
--
ALTER TABLE `prioritas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `program`
--
ALTER TABLE `program`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_programunor_unoreselon11_idx` (`unoreselon1_id`);

--
-- Indexes for table `sasaran`
--
ALTER TABLE `sasaran`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_sasarankegiatanunor_kegiatanunor1_idx` (`kegiatan_id`);

--
-- Indexes for table `sasaranstrategis`
--
ALTER TABLE `sasaranstrategis`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_sasaranstrategisunor_unoreselon11_idx` (`unoreselon1_id`);

--
-- Indexes for table `triwulan`
--
ALTER TABLE `triwulan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `unggulan`
--
ALTER TABLE `unggulan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `unoreselon1`
--
ALTER TABLE `unoreselon1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `unoreselon2`
--
ALTER TABLE `unoreselon2`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_unoreselon2_unoreselon11_idx` (`unoreselon1_id`);

--
-- Indexes for table `unoreselon3`
--
ALTER TABLE `unoreselon3`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_unoreselon3_unoreselon21_idx` (`unoreselon2_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_groups`
--
ALTER TABLE `users_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uc_users_groups` (`user_id`,`group_id`),
  ADD KEY `fk_users_groups_users1_idx` (`user_id`),
  ADD KEY `fk_users_groups_groups1_idx` (`group_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dukungan`
--
ALTER TABLE `dukungan`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `ikktahunan`
--
ALTER TABLE `ikktahunan`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ikstriwulan`
--
ALTER TABLE `ikstriwulan`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `iku`
--
ALTER TABLE `iku`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `indikatorkinerjakegiatan`
--
ALTER TABLE `indikatorkinerjakegiatan`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT for table `indikatorkinerjasasaran`
--
ALTER TABLE `indikatorkinerjasasaran`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `jenisoutput`
--
ALTER TABLE `jenisoutput`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `kegiatan`
--
ALTER TABLE `kegiatan`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `login_attempts`
--
ALTER TABLE `login_attempts`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `misi`
--
ALTER TABLE `misi`
  MODIFY `id` tinyint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `outcome`
--
ALTER TABLE `outcome`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `output`
--
ALTER TABLE `output`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `pktbiro`
--
ALTER TABLE `pktbiro`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=79;
--
-- AUTO_INCREMENT for table `prioritas`
--
ALTER TABLE `prioritas`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `program`
--
ALTER TABLE `program`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `sasaran`
--
ALTER TABLE `sasaran`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `sasaranstrategis`
--
ALTER TABLE `sasaranstrategis`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `triwulan`
--
ALTER TABLE `triwulan`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `unggulan`
--
ALTER TABLE `unggulan`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `unoreselon1`
--
ALTER TABLE `unoreselon1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `unoreselon2`
--
ALTER TABLE `unoreselon2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `unoreselon3`
--
ALTER TABLE `unoreselon3`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `users_groups`
--
ALTER TABLE `users_groups`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `ikktahunan`
--
ALTER TABLE `ikktahunan`
  ADD CONSTRAINT `fk_targettahunan_indikatorkinerjakegiatan1` FOREIGN KEY (`indikatorkinerjakegiatan_id`) REFERENCES `indikatorkinerjakegiatan` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `ikstriwulan`
--
ALTER TABLE `ikstriwulan`
  ADD CONSTRAINT `fk_targettriwulan_indikatorkinerja1` FOREIGN KEY (`indikatorkinerjasasaran_id`) REFERENCES `indikatorkinerjasasaran` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `iku`
--
ALTER TABLE `iku`
  ADD CONSTRAINT `fk_ikuunor_unoreselon11` FOREIGN KEY (`unoreselon1_id`) REFERENCES `unoreselon1` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `indikatorkinerjakegiatan`
--
ALTER TABLE `indikatorkinerjakegiatan`
  ADD CONSTRAINT `fk_indikatorkinerjakegiatanunor_dukungan1` FOREIGN KEY (`dukungan_id`) REFERENCES `dukungan` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_indikatorkinerjakegiatanunor_sasaran1` FOREIGN KEY (`sasaran_id`) REFERENCES `sasaran` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `indikatorkinerjasasaran`
--
ALTER TABLE `indikatorkinerjasasaran`
  ADD CONSTRAINT `fk_indikatorkinerja_indikatorkinerjakegiatan1` FOREIGN KEY (`indikatorkinerjakegiatan_id`) REFERENCES `indikatorkinerjakegiatan` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_indikatorkinerja_unoreselon31` FOREIGN KEY (`unoreselon3_id`) REFERENCES `unoreselon3` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `kegiatan`
--
ALTER TABLE `kegiatan`
  ADD CONSTRAINT `fk_kegiatanunor_unoreselon11` FOREIGN KEY (`unoreselon1_id`) REFERENCES `unoreselon1` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_kegiatanunor_unoreselon21` FOREIGN KEY (`unoreselon2_id`) REFERENCES `unoreselon2` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `misi`
--
ALTER TABLE `misi`
  ADD CONSTRAINT `fk_misiunor_unoreselon1` FOREIGN KEY (`unoreselon1_id`) REFERENCES `unoreselon1` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `outcome`
--
ALTER TABLE `outcome`
  ADD CONSTRAINT `fk_outcomeunor_unoreselon11` FOREIGN KEY (`unoreselon1_id`) REFERENCES `unoreselon1` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `program`
--
ALTER TABLE `program`
  ADD CONSTRAINT `fk_programunor_unoreselon11` FOREIGN KEY (`unoreselon1_id`) REFERENCES `unoreselon1` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
